import onnxruntime as rt
import sclblonnx as so
import onnx
import numpy as np
import argparse, sys
import pickle

def main():
    parser=argparse.ArgumentParser()

    parser.add_argument('--onnx_file', help='Select the ONNX File')
    parser.add_argument('--input_file', help='Insert the file that contains the input tensor (a list) to be fed to the network')
    args=parser.parse_args()

    onnx_run_second_half(args.onnx_file, args.input_file)

# Run at inference the Second Half of the Splitted Model
def onnx_run_second_half(onnx_file, input_file):
  #Get the input and output of the model
  onnx_model = onnx.load(onnx_file)
  model_input = onnx_model.graph.input[0].name 
  model_output = onnx_model.graph.output[0].name

  #Get the input tensor fromt the file
  with open(input_file, 'rb') as f:
    input_tensor = pickle.load(f)

  # Run the second model with the results from the first model as input
  g = so.graph_from_file(onnx_file)

  inputs = {model_input: input_tensor}
  result = so.run(g,
                  inputs=inputs,
                  outputs=[model_output]
                  )
  print(result)
  return result

if __name__ == "__main__":
    main()
